# React chess

Starter code for the tutorial of building a chess application with react